import React, { Component } from 'react';
import "../css/Login.css";

class Follow extends Component{

    constructor(props) {
        super(props);
    }

    render(){
        return(
            'Follow'
        );
    }

}

export default Follow;