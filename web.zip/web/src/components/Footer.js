import React, { Component } from 'react';
import "../css/Footer.css";

class Footer extends Component{

    constructor(props){
        super(props);
    }

    render(){
        return(

            <footer>
                <div>

                </div>
                <div>

                </div>
            </footer>

        );
    }

}

export default Footer;