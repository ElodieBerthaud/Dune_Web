import React, { Component } from 'react';
import "../css/Login.css";

class Professor extends Component{

    constructor(props) {
        super(props);
    }

    render(){
        return(
            'Professor'
        );
    }

}

export default Professor;