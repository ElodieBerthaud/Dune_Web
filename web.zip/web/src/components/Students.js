import React, { Component } from 'react';
import "../css/Login.css";

class Students extends Component{

    constructor(props) {
        super(props);
    }

    render(){
        return(
            'Students'
        );
    }

}

export default Students;