import {Component} from "react";

class FullTest extends Component {
    render() {
        return (

            'test'

        );
    }
}

export default FullTest;